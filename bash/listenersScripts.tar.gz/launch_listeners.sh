# python is at the end since it is sudo
mate-terminal --geometry=100x25 --tab --title="nc-8443" -e "bash -c \"echo 'nc -lvp 8443';/home/bikeride/htb/cybernetics/shell/nc_8443.sh; exec bash\"" --tab --title="nc-8081" -e "bash -c \"echo 'nc -lvp 8081'; /home/bikeride/htb/cybernetics/shell/nc_8081.sh; exec bash\"" --tab --title="python-80" -e "bash -c \"echo 'sudo python -m SimpleHTTPServer 80'; /home/bikeride/htb/cybernetics/shell/python_80.sh; exec bash\"" 

# ;exec bash\

# gnome-terminal --geometry=150x50 --tab --title="echo" -e "bash -c \"echo "hello";echo "there";exec bash\"" --tab --title="idea"
# -e "bash -c \"/opt/idea-IU-111.69/bin/idea.sh;exec bash\"" 
